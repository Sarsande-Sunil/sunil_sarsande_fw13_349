const mongoose = require("mongoose");

const bcrypt = require('bcrypt');

// make user models here

const userschema = new mongoose.Schema(
    {
  id: { type: Number, required: true },
  firstName: { type: String, required: true, min: 3, max: 30 },
  lastName: { type: String, required: true, min: 3, max: 30 },
  age: { type: Number, required: true, min: 1, max: 150 },
  email: { type: String, required: true, unique: true },
  profileImages:[{type:String,required:true}]
    },
    {
    versionKey:false,
    timestamps:true,
   }
);

// hashing password
userschema.pre("save", function (next) {
    if (!this.isModified("password")) {
        return next();
    }
    var hash = bcrypt.hashSync(this.password,10);
    this.password = hash;
    next();
})

// matching the password
userschema.method.checkpassword = function (user) {
    return bcrypt.compareSync(password.this.passwords)
}

const User = mongoose.model("user", userschema);


// make user post  models here

const postschema = new mongoose.Schema(
  {
    id: { type: Number, required: true },
    body: { type: String, required: true },
    likes: { type: Number, required: true, default: 0 },
    image: { type: String, required: true },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      required: true,
    },
  },
  {
    versionKey: false,
    timestamps: true,
  }
);

const Post = mongoose.model("post",postschema);


// make user postlike  models here

const postlikeschema = new mongoose.Schema(
  {
    postId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "post",
      required: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      required: true,
    },
  },
  {
    versionKey: false,
    timestamps: true,
  }
);

const Postlike = mongoose.model("postlike", postlikeschema);

const commentSchema = new mongoose.Schema(
  {
    body: { type: String, required: true },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      required: true,
    },
    postId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "post",
      required: true,
    },
  },
  {
    versionKey: false,
    timestamps: true,
  }
);

const Comment  = mongoose.model("comment", commentSchema);

module.exports = { User, Post, Postlike, Comment };

// export all file in controllers
