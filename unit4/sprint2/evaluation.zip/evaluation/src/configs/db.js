const mongoose = require("mongoose");

module.exports = () => {
    return mongoose.connect(
      "mongodb+srv://sunil:sarsande1234@cluster0.a3pf2.mongodb.net/sprint4?retryWrites=true&w=majority"
    );
}