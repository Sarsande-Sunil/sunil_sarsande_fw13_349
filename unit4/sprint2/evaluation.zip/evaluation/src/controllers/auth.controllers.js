require("dotenv").config();

var jwt = require("jsonwebtoken");

const { User, Post, Postlike, Comment } = require("../models/users.models");

var newToken = (user) => {
    jwt.sign({user}, process.env.JWT_SECRET_KEY);
}

const register = async (req, res) => {
    try {
        
        var user = await User.findOne({ email: req.body.email }).lean().exec(); 
        if (!user) {
            res.status(400).send("olease enter another emai")
        }
        
        user = await User.create(req.body)

        var token = newToken(user);
        res.send({user,token})
    }
    catch (e) {
       res.send(e.messsage)        
    }
}

const login = async (req, res) => {
  try {
    var user = await User.findOne({ email: req.body.email });
    if (!user) {
      res.status(400).send("olease enter another emai or password");
    }

    var match = user.checkpassword(req.body.password)

      if (!match) {
        res.status(400).send("olease enter another emai or password");  
      }

    var token = newToken(user);
    res.send({ user, token });
  } catch (e) {
    res.send(e.messsage);
  }
};