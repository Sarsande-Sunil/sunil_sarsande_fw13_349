const {body,validationResult} = require("express-validator")
const express = require("express");

const { User, Post, Postlike, Comment } = require("../models/users.models");

const router = express.Router();

router.post( 
  "",
  body("id")
    .isNumeric()
    .withMessage("put correct id")
    .bail()
    .custom(async (value) => {
      const user = await User.findOne({ id: value });
      if (user) {
        throw new Error("id to barabr daal");
      }
      return true;
    }),
  body("firstName")
    .isString()
    .isLowercase()
    .isLength({ min: 3, max: 30 })
    .withMessage("naam to barab dalo bhai"),
  body("lastName")
    .isString()
    .isLowercase()
    .isLength({ min: 3, max: 30 })
    .withMessage("naam to barab dalo bhai"),
  body("email").isEmail()
    .custom(async (value) => {
      const user = await User.findOne({ email: value });
      if (user) {
        throw new Error(" email barabr dalo bhai")
      }
      return true;
    }),
  body("password")
    .isLength({ min: 8, max: 16 })
    .custom(async (value) => {
      let passpattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9].{8,}$/;
      if (passpattern.test(value)) {
        return true;
      }
      throw new Error("password is not stroong")
    }),

  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        let newErrors;
        newErrors = errors.array().map((err) => {
          return {key:err.param,message:err.msg}
        })
        return res.send({ errors: newErrors })
      }
      const user = await User.create(req.body);
      return res.send(user);
    }
    catch (e) {
      console.log(err.message)
    }
 });

 // post request
router.post("/post", async (res, req) => {
   try{
     const post = await Post.create(req.body);
     res.send(post);
   }
   catch(e) {
     res.send(e.message)
   }
 })

 // comment post router
 router.post("/comment", async (res, req) => {
   try {
    const comments = await Comment.create(req.body);
    res.send(comments);
   }
   catch(e){
     res.send(e.message);
   }
 });

router.post("/:post", async (req, res) => {
  try {
    const page = req.query.page || 1;
    const size = req.query.page || 10;

    const query = {post:req.params.post};
    const users = await User.find(query)
      .skip(page - 1)
    .limit(size)
      .lean()
      .exec()
    
    const totalpage = Math.ceil(await User.find(query).countDocuments());
    return res.send(users,totalpage)
  }
  catch(e) {
    res.send(e.message);
  }
})

module.exports = router;