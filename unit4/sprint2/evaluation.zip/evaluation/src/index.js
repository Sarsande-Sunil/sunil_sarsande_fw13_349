const express = require("express");
const connect = require("./configs/db")
const res = require("express/lib/response");

const userControllers = require("./controllers/users.controllers")
const app = express();

app.use(express.json());

app.use("/users", userControllers);

app.listen(2346, async () => {
    try {
        await connect();
       console.log("running on port 2346") 
    }
    catch(e) {
     console.log(e.message)
    }
})